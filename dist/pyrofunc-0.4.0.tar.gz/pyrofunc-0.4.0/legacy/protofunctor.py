from typing import Callable, TypeVar, Generic, Union

# Generic types for Functor/Monad
T = TypeVar('T')
R = TypeVar('R')
S = TypeVar('S')

class FunctorMonad(Generic[T, R]):
    def __init__(self, value: T, **kwargs):
        self.__dtype__ = type(value).__name__
        self._value = value
        self.__meta__ = kwargs
        self.__logs__ = []

    def __call__(self, func: Callable[[T], R]) -> 'FunctorMonad':
        print(f"{self.__class__.__name__}.__call__({func.__name__})")
        self._value = func(self._value)
        return self

    def __rshift__(self, func: Union[Callable[[T], R], 'FunctorMonad']) -> 'FunctorMonad':
        if hasattr(func, "_instance"):
            print(f"{self.__class__.__name__}.__rshift__({func._instance.__class__.__name__})")
            self._value = func._instance(self._value)
        elif callable(func):
            print(f"{self.__class__.__name__}.__rshift__({func.__name__})")
            self._value = func(self._value)
        else:
            raise TypeError(f"Unsupported type for >> operation: {type(func)}")
        return self

    def __or__(self, cast_type):
        print(f"{self.__class__.__name__}.__or__({cast_type})")
        if isinstance(cast_type, FunctorMonad):
            return cast_type(self)
        else:
            self._value = cast_type(self._value)
            return self

    def __repr__(self):
        return f'{self.__dtype__}({self._value})'

    def __exec__(self, func: Callable[[T], R]) -> 'FunctorMonad':
        print(f"{self.__class__.__name__}.__exec__({func.__name__})")
        self._value = func(self._value)
        self.__logs__.append(f"{func.__name__}({self._value})")
        return self

    def log(self):
        return self.__logs__

# Decorator for functor-like functionality
def functor(cls):
    class WrappedFunctor(FunctorMonad):
        def __init__(self, *args, **kwargs):
            self._instance = cls(*args, **kwargs)

        def __call__(self, value):
            print(f"{self._instance.__class__.__name__}({value})")
            return self._instance(value)

    return WrappedFunctor

# Example functors
@functor
class Add:
    def __init__(self, y: int):
        self.y = y

    def __call__(self, x: int) -> int:
        print(f"Add({x}, {self.y})")
        return x + self.y

@functor
class Multiply:
    def __init__(self, factor: int):
        self.factor = factor

    def __call__(self, x: int) -> int:
        print(f"Multiply({x}, {self.factor})")
        return x * self.factor

@functor
class AddOne:
    def __call__(self, x: int) -> int:
        print(f"AddOne({x})")
        return x + 1

# Usage demonstration
if __name__ == "__main__":
    # Using the unified FunctorMonad
    result = FunctorMonad(5) | Add(3) >> Multiply(20) | float
    print(f"Result 1: {result}")

    composite = Add(3) >> Multiply(25)
    result = FunctorMonad(5) | composite >> Add(3) >> AddOne >> Multiply(2) | float
    print(f"Result 2: {result}")

    # Logs demonstration
    result = FunctorMonad(5) | Add(3) >> Multiply(20)
    print(f"Logs: {result.log()}")
