import copy
from typing import Callable, TypeVar, Generic, Union

# Generic types for Functor and Monad
T = TypeVar('T')
R = TypeVar('R')
S = TypeVar('S')

# Monad implementation
class Monad(Generic[T]):
    __mtype__ = "Monad"

    def __init__(self, value: T, **kwargs):
        self.__dtype__ = type(value).__name__
        self.__value__ = value
        self.__kwargs__ = kwargs
        self.__pre__ = []

    def __exec__(self, func: Callable[[T], 'Monad[R]']) -> 'Monad[R]':
        print(f"{self.__class__.__name__}.__exec__({func.__name__})")
        # Re-create the Monad instance with the new value
        print("pre monad._value".ljust(20), self.__value__)
        self.__pre__.append(copy.deepcopy(self))
        # Run the functor, updating __value__ in place
        self = func(self)
        history_entry = {"functor": func.__class__.__name__, "input": self.__pre__, "output": self}
        print(f"history_entry".ljust(20), history_entry)
        print("post monad._value".ljust(20), self.__value__)
        # Applies a function that returns a new Monad
        return self

    def __call__(self, *args, **kwargs):
        print(f"{self.__class__.__name__}.__call__({args}, {kwargs})")
        # Overload () operator for calling the value
        return self.__exec__(*args, **kwargs)

    def __rshift__(self, func: 'Functor[[T], R]') -> 'Functor[S, R]':
        """
        Compose the monad with a functor using >> operator.
        :param func: The functor to apply to the monad's value.
        :return:
        """
        print(f"{self.__class__.__name__}.__rshift__({func.__name__})")
        assert isinstance(func, Functor), f"{self.__class__.__name__}.__rshift__({func}):" \
                                          f"Expected Functor, got {type(func)}"
        self = func(self)
        return self

    def __or__(self, cast_type):
        print(f"{self.__class__.__name__}.__or__({cast_type.__class__.__name__})")
        # Cast the value into a functor
        if isinstance(cast_type, Functor):
            return cast_type(self)
        # Cast the value to a different type
        else:
            return cast_type(self.__value__)

    def __repr__(self):
        return f'{self.__dtype__}({self.__value__})'


# Functor class
class Functor(Generic[T, R]):
    __name__ = "Functor"

    # def __new__(cls, *args, **kwargs):
    #     print(f"{cls.__name__}.__new__({args}, {kwargs})")
    #     # Create and return a Monad instance instead of a Functor instance
    #     if hasattr(cls, '__init__') and cls.__init__ is not Functor.__init__:
    #         # If the class has a custom __init__ method, call it
    #         print(f"Creating instance of {cls.__name__} with args: {args} and kwargs: {kwargs}")
    #         return super().__new__(cls)
    #     #elif hasattr(cls, '__exec__'):
    #     #    # If no custom __init__, call __exec__ instead
    #     #    print("Running Functor without __init__")
    #     #    return cls.__exec__(*args, **kwargs)
    #     #else:
    #     #    raise AttributeError(f"{cls.__name__} is not a proper Functor."
    #     #                         f"It  has neither a defined __init__ nor an __exec__ method.")

    def __exec__(self, monad: Monad[T]) -> Monad[R]:
        # Apply the functor to the monad's value from the children classes
        raise NotImplementedError(f"{self.__class__.__name__}.__exec__({monad}):")

    def __call__(self, value, *args, **kwargs) -> R:
        assert isinstance(value, Monad), f"{self.__class__.__name__}.__call__({value}):" \
                                         f"Expected Monad, got {type(value)}"
        print(f"{self.__class__.__name__}.__call__({value})")
        value.__value__ = self.__exec__(value.__value__)
        return value

    def __ror__(self, monad: Monad[T]) -> Monad[R]:
        print(f"{self.__class__.__name__}.__ror__({monad})")
        assert isinstance(monad, Monad), f"Prototype 57: {self.__class__.__name__}.__ror__({monad})" \
                                         f"Expected Monad, got {type(monad)}"
        # Overload | operator for chaining with Monads or raw values
        if isinstance(monad, Monad):
            monad._value = self(monad._value)
            return monad
        raise TypeError(f"{self.__class__.__name__}.__ror__({monad}): "
                        f"Expected Monad, got {type(monad)}")
        # Unaccessible code, will have to rethink the types signature to review if we can indeed wrap the value here
        return Monad(self(monad))

    def __rshift__(self, other: 'Functor') -> 'Functor':
        print(f"{self.__class__.__name__}.__rshift__({other.__name__})")
        # Compose functors using >>
        class CompositeFunctor(Functor):
            def __init__(self, first: 'Functor[[T], R]', second: 'Functor[[R], S]') -> 'Functor[[T], S]':
                # Will move eventually to an arbitrary number of functors
                self.operations = [first, second]
                # Todo add internal types validation, cache info and generalize
                self.first = first
                self.second = second
                self.__name__ = f"{first.__class__.__name__}.{second.__class__.__name__}"

            def __call__(self, value: 'Monad[T]') -> 'Monad[S]':
                assert isinstance(value, Monad), f"{self.__class__.__name__}.__call__({value}):" \
                                                 f"Expected Monad, got {type(value)}"
                print(f"{self.first.__class__.__name__}({value}) >> {self.second.__class__.__name__}")
                # Apply the first functor, then the second
                print(f"v0".ljust(20), value)
                if isinstance(value, Monad):
                    value.__exec__(self.first)
                    print(f"v1.1".ljust(20), value)
                    value.__exec__(self.second)
                else:
                    print("ERRRa")
                    value = Monad(self.first(value))
                    print(f"v1.2".ljust(20), value)
                    value = Monad(self.second(value))
                print(f"v2".ljust(20), value)
                print(f"type(value._value)".ljust(20), type(value.__value__))
                return value
        return CompositeFunctor(self, other)

# Decorator to dynamically create functor classes
def functor(cls):
    """ Class decorator that dynamically creates a new class inheriting from Functor."""
    return type(cls.__name__, (Functor,), dict(cls.__dict__))

def staticfunctor(cls):
    """
    Class decorator that dynamically creates a new class inheriting from Functor and the target class.
    """
    # Create a new class dynamically with Functor as a base
    @staticmethod
    def functor_call(value: Monad[T], *args, **kwargs):
        return cls.__exec__(value)

    def __call__(cls, value, *args, **kwargs) -> R:
        assert isinstance(value, Monad), f"{cls.__name__}.__call__({value}):" \
                                         f"Expected Monad, got {type(value)}"
        print(f"{cls.__name__}.__call__({value})")
        value.__value__ = cls.__exec__(value.__value__)
        return value

    cls.__new__ = __call__

    return cls

# Example functors
@functor
class Add:
    def __init__(self, y: int):
        self.y = y

    def __exec__(self, x: int) -> int:
        print(f"Add({x}, {self.y})")
        return x + self.y

@functor
class Multiply:
    def __init__(self, factor: int):
        self.factor = factor

    def __exec__(self, x: int) -> int:
        print(f"Multiply({x}, {self.factor})")
        return x * self.factor

@staticfunctor
class AddOne:
    # def __new__(cls, *args):
    #    # Create and return a Monad instance instead of an AddOne instance
    #    return cls.__exec__(*args)

    @staticmethod
    def __exec__(x: int) -> int:
        print(f"AddOne({x})")
        return x + 1

# Monad with logging capabilities
class MonadWithLogs(Monad):
    def __init__(self, value: T):
        super().__init__(value)
        self.__logs__ = []

    def __exec__(self, func: 'Functor[T, R]') -> 'MonadWithLogs[R]':
        print(f"{self.__class__.__name__}.MonadWithLogs.__exec__({func.__name__})")
        self = func(self)
        self.__logs__.append(f"{func.__name__}({self.__value__})")
        return self


def extract_logs(value: MonadWithLogs):
    print(f"extract_logs({value.__value__})")
    print(f"Value type: {type(value)}")
    print(f"dtype: {value.__dtype__}")
    return value.__logs__

# Usage demonstration
if __name__ == "__main__":
    # Using Monad in the pipeline
    result = Monad(5) | Add(3) >> Multiply(20) | float
    print(f"Result 1: {result}")
    composite = Add(3) >> Multiply(25)
    #print(result)  # Output: 160.0
    # Using Monad with instantiated functors
    result = Monad(5) | composite >> Add(3) >> AddOne >> Multiply(2) | float
    print(f"Result 2: {result}", flush=True)  # Output: 160.0
    # Let's kick it up a notch
    # We will now run with logs
    result = MonadWithLogs(5) | composite >> Add(3) >> AddOne >> Multiply(2)
    print(f"Result log: {result.__logs__}")
    print(f"Result 3: {result}")
